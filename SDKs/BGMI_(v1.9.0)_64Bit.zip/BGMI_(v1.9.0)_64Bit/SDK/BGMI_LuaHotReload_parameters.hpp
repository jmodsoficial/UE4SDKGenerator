#pragma once

// Battlegrounds Mobile India (1.9.0) SDK by Dyno

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function LuaHotReload.LuaHotReloadHelper.OnLuaFileHotUpdate
struct ULuaHotReloadHelper_OnLuaFileHotUpdate_Params
{
	struct FString                                     NotifyMessage;                                            // (Parm, ZeroConstructor)
};

}

