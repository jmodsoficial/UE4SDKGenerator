#pragma once

// Battlegrounds Mobile India (1.9.0) SDK by Dyno

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass BpOverWrite.BpOverWrite_C
// 0x0000 (0x0190 - 0x0190)
class UBpOverWrite_C : public UBPClassManager
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("BlueprintGeneratedClass BpOverWrite.BpOverWrite_C");
		return pStaticClass;
	}

};


}

