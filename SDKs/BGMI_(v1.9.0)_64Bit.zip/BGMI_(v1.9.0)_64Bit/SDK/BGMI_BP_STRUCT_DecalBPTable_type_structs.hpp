#pragma once

// Battlegrounds Mobile India (1.9.0) SDK by Dyno

namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_DecalBPTable_type.BP_STRUCT_DecalBPTable_type
// 0x0060
struct FBP_STRUCT_DecalBPTable_type
{
	int                                                ID_0_0CAD9D8055C0CD6A25A0DCEE0A0553D4;                    // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FString                                     Path_1_0033FD807638E0C45A483151055262A8;                  // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     CName_2_6D7E0B40638C94B731ACB8980538E865;                 // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     DefaultTexturePath_3_3BA6EB00368C49AC4F31B2080CB16AE8;    // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     FlipBookTexturePath_4_75157F4004E82529477143F20510B968;   // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                soundID_5_6F0D27C03EADFE7B44B5857B0ACC1DD4;               // 0x0048(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x004C(0x0004) MISSED OFFSET
	struct FString                                     soundPath_6_09E147C024FF3AFD468FAA630C1C6268;             // 0x0050(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

