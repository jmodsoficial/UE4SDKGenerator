#pragma once

// Battlegrounds Mobile India (1.9.0) SDK by Dyno

namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_VehicleRefitBPTable_type.BP_STRUCT_VehicleRefitBPTable_type
// 0x0030
struct FBP_STRUCT_VehicleRefitBPTable_type
{
	struct FString                                     Path_0_367735C04445450711936E2507D65338;                  // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                SkinID_1_178D3B00586DF4A03398AF2E06BA7504;                // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                TemplateID_2_188844C035CA84B912116AE102FE3804;            // 0x0014(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                ID_3_7E5115C05AFA7931402A62180B97D7E4;                    // 0x0018(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x001C(0x0004) MISSED OFFSET
	struct FString                                     LobbyPath_6_1DD513C07D99921F4DE3874A01E3EA48;             // 0x0020(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

