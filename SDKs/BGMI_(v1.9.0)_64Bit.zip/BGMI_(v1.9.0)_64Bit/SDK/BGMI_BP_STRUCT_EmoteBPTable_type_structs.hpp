#pragma once

// Battlegrounds Mobile India (1.9.0) SDK by Dyno

namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_EmoteBPTable_type.BP_STRUCT_EmoteBPTable_type
// 0x0048
struct FBP_STRUCT_EmoteBPTable_type
{
	struct FString                                     Path_0_247605C000C1809320361CC70BC26958;                  // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     CName_1_20BFF38058E1993E3181765E0C385985;                 // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                ID_2_6D1FE5C03D4B9B6365DA363A01FBC3D4;                    // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0024(0x0004) MISSED OFFSET
	struct FString                                     LobbyPath_3_17CBE3C0186812E1377BBB6D07222BE8;             // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     LobbyEmoteAdapt_4_6274998039C4B44E5D4A1AFE0DB5A954;       // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

