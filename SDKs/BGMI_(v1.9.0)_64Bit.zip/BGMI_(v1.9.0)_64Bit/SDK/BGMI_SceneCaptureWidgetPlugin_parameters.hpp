#pragma once

// Battlegrounds Mobile India (1.9.0) SDK by Dyno

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function SceneCaptureWidgetPlugin.SceneCaptureWidget.SetSceneCaptureCameraActor
struct USceneCaptureWidget_SetSceneCaptureCameraActor_Params
{
	class ASceneCaptureCameraActor*                    InSceneCaptureCameraActor;                                // (Parm, ZeroConstructor, IsPlainOldData)
};

}

