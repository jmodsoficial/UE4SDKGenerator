#pragma once

// Battlegrounds Mobile India (1.9.0) SDK by Dyno

namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_VehicleRefitColorTable_type.BP_STRUCT_VehicleRefitColorTable_type
// 0x0048
struct FBP_STRUCT_VehicleRefitColorTable_type
{
	int                                                ID_0_7607F1003C307130785E051708091744;                    // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Gray_1_23C2528073E753A86CAE45C709177089;                  // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FString                                     Color3_2_133F1A40217781872E65F412071E3F43;                // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Color2_3_133E1A00217781862E65F413071E3F42;                // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Color1_4_133D19C0217781852E65F410071E3F41;                // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     ColorBPPath_5_507BD54027F0DEF913818BAA07048B58;           // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

