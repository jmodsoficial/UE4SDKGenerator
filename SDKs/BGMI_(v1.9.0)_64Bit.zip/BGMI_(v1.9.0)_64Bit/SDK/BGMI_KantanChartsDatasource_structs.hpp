#pragma once

// Battlegrounds Mobile India (1.9.0) SDK by Dyno

namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct KantanChartsDatasource.KantanCartesianDatapoint
// 0x0008
struct FKantanCartesianDatapoint
{
	struct FVector2D                                   Coords;                                                   // 0x0000(0x0008) (Edit, BlueprintVisible, IsPlainOldData)
};

}

